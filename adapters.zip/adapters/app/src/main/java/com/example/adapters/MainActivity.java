package com.example.adapters;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.adapters.adapter.UserAdapter;
import com.example.adapters.model.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = (ListView) findViewById(R.id.list);
//        List<String> item = new ArrayList<>(Arrays.asList("Mike","Frank","Shokir","Jahongir"));
//        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.simple_layout,item);

        ArrayList<User> users = new ArrayList<>();
        users.add(new User("Sanjar Bekov", "Tashkent"));

        UserAdapter adapter = new UserAdapter(this, users);
        users.add(new User("Hamidullo Xasanov", "Tashkent"));

        listView.setAdapter(adapter);
        users.add(new User("Akbar Akhrorkulov", "Tashkent"));

        adapter.notifyDataSetChanged();
    }
}
