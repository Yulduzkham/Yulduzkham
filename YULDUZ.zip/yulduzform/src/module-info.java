module yulduzform {
	exports yulduzform;

	requires java.desktop;
}