package Dilorom_c;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
public class calculator {

	private JFrame frame;
	private JTextField textField1;
	private JTextField textField2;
	private JTextField textFieldAns;

	/**

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calculator window = new calculator();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public calculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 310, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField1 = new JTextField();
		textField1.setBounds(10, 11, 119, 33);
		frame.getContentPane().add(textField1);
		textField1.setColumns(10);
		
		textField2 = new JTextField();
		textField2.setBounds(151, 11, 119, 33);
		frame.getContentPane().add(textField2);
		textField2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Answer");
		lblNewLabel.setBounds(10, 220, 58, 14);
		frame.getContentPane().add(lblNewLabel);
		
		textFieldAns = new JTextField();
		textFieldAns.setBounds(94, 211, 176, 33);
		frame.getContentPane().add(textFieldAns);
		textFieldAns.setColumns(10);
		
		JButton ButtonAdd = new JButton("+");
		ButtonAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int num1, num2,ans;
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					ans=num1+num2;
					textFieldAns.setText(Integer.toString(ans));
					
			}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Enter valid number");
				}
				}
		});
		ButtonAdd.setFont(new Font("Tahoma", Font.BOLD, 15));
		ButtonAdd.setBounds(10, 97, 58, 46);
		frame.getContentPane().add(ButtonAdd);
		
		JButton btnNewButton_1 = new JButton("-");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int num1, num2,ans;
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					ans=num1-num2;
					textFieldAns.setText(Integer.toString(ans));
					
			}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Enter valid number");
			}
			}
		});
		btnNewButton_1.setBounds(78, 97, 58, 46);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("/");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int num1, num2,ans;
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					ans=num1/num2;
					textFieldAns.setText(Integer.toString(ans));
					
			}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Enter valid number");
			}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(144, 97, 58, 46);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("*");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int num1, num2,ans;
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					ans=num1*num2;
					textFieldAns.setText(Integer.toString(ans));
					
			}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Enter valid number");
			}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBounds(212, 97, 58, 46);
		frame.getContentPane().add(btnNewButton_3);
	}
}

