import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class calculator {

	private JFrame frame;
	private JTextField textField;
	private JTextComponent inputBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calculator window = new calculator();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public calculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 257, 399);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(6, 16, 245, 39);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("7");
		btnNewButton.setBounds(6, 67, 53, 46);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("8");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(71, 67, 53, 46);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("9");
		btnNewButton_2.setBounds(136, 67, 53, 46);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("+");
		btnNewButton_3.setBounds(198, 67, 53, 46);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("4");
		btnNewButton_4.setBounds(6, 131, 53, 46);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("5");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5.setBounds(71, 131, 53, 46);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("6");
		btnNewButton_6.setBounds(136, 131, 53, 47);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("-");
		btnNewButton_7.setBounds(198, 131, 53, 46);
		frame.getContentPane().add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("*");
		btnNewButton_8.setBounds(198, 193, 53, 46);
		frame.getContentPane().add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("/");
		btnNewButton_9.setBounds(198, 251, 53, 44);
		frame.getContentPane().add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("1");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_10.setBounds(6, 198, 53, 41);
		frame.getContentPane().add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("3");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_11.setBounds(136, 196, 53, 43);
		frame.getContentPane().add(btnNewButton_11);
		
		JButton btnNewButton_12 = new JButton("2");
		btnNewButton_12.setBounds(71, 197, 53, 46);
		frame.getContentPane().add(btnNewButton_12);
		
		JButton btnNewButton_13 = new JButton("0");
		btnNewButton_13.setBounds(72, 259, 53, 46);
		frame.getContentPane().add(btnNewButton_13);
		
		JButton btnNewButton_14 = new JButton("=");
		btnNewButton_14.setBounds(198, 300, 53, 71);
		frame.getContentPane().add(btnNewButton_14);
		
		JLabel lblNewLabel = new JLabel("Calculator by Dilorom");
		lblNewLabel.setBounds(6, 355, 183, 16);
		frame.getContentPane().add(lblNewLabel);
	}
		public void actionPerformed(ActionEvent e) {
		      String command = e.getActionCommand();
		      if (command.charAt(0) == 'C') {                      
		         inputBox.setText("");
		      }else if (command.charAt(0) == '=') {                    
		         inputBox.setText(evaluate(inputBox.getText()));
		      }else {                                
		         inputBox.setText(inputBox.getText() + command);
		      }
		   }
		 
		   public static String evaluate(String expression) {
		      char[] arr = expression.toCharArray();
		      String operand1 = "";String operand2 = "";String operator = "";
		      double result = 0;

		      for (int i = 0; i < arr.length; i++) {
		         if (arr[i] >= '0' && arr[i] <= '9' || arr[i] == '.') {
		            if(operator.isEmpty()){
		               operand1 += arr[i];
		            }else{
		               operand2 += arr[i];
		            }
		         }  

		         if(arr[i] == '+' || arr[i] == '-' || arr[i] == '/' || arr[i] == '*') {
		            operator += arr[i];
		         }
		      }

		      if (operator.equals("+"))
		         result = (Double.parseDouble(operand1) + Double.parseDouble(operand2));
		      else if (operator.equals("-"))
		         result = (Double.parseDouble(operand1) - Double.parseDouble(operand2));
		      else if (operator.equals("/"))
		         result = (Double.parseDouble(operand1) / Double.parseDouble(operand2));
		      else
		         result = (Double.parseDouble(operand1) * Double.parseDouble(operand2));          
		      return operand1 + operator + operand2 + "=" +result;
		   
	}
}
